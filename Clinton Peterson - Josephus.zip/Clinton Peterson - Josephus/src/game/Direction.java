package game;

public enum Direction
{
	LEFT,
	RIGHT
}
