package examples;

public class StringStorage
{
	//field
	private String data;
	
	//constructor
	public StringStorage(String data)
	{
		this.data = data;
	}
	
	//methods
	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}	
}
