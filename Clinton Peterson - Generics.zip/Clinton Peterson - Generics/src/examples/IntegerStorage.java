package examples;

public class IntegerStorage
{
	//field
	private int data;
	
	//constructor
	public IntegerStorage(int data)
	{
		this.data = data;
	}
	
	//methods
	public int getData() {
		return data;
	}

	public void setData(int data) {
		this.data = data;
	}	
}
