package examples;

public class SportsCar extends DigitalCar 
{
	//field
	
	
	//constructor
	
	
	//methods
	
}
