package examples;

public class DigitalCar implements Comparable<DigitalCar>
{
	//field
	
	
	//constructor
	
	
	//methods
	public void drive()
	{
		//does something
	}

	@Override
	public int compareTo(DigitalCar o) {
		// TODO Auto-generated method stub
		return 0;
	}
			
	
}
