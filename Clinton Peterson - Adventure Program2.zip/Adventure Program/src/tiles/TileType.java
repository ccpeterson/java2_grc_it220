package tiles;
/**
 * Project: Adventure Program 
 * 10/24/17
 * @author Clinton Peterson
 */
public enum TileType
{
	GRASS,
	MUD,
	ROAD,
	TRAP
}
